import React from 'react';
import { Pie } from 'react-chartjs-2';
import CallStatsCard from '../components/CallStatsCard';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import Navbar from '../components/Navbar';
import Sidebar from '../components/Sidebar';
import DashboardCards from '../components/DashboardCards';

ChartJS.register(ArcElement, Tooltip, Legend);

const Dashboard = () => {
  const data = {
    labels: ['WhatsApp Calls', 'Normal Calls', 'Unanswered Calls'],
    datasets: [
      {
        data: [50, 30, 15],
        backgroundColor: ['#4e73df', '#1cc88a', '#36b9cc'],
        borderColor: ['#ffffff', '#ffffff', '#ffffff'],
      },
    ],
  };

  return (
    <div id="wrapper">
      <Sidebar />
      <div className="d-flex flex-column" id="content-wrapper">
        <div id="content">
          <Navbar />
          <div className="container-fluid">
            <div className="d-sm-flex justify-content-between align-items-center mb-4">
              <h3 className="text-dark mb-0">Dashboard</h3>
              <a className="btn btn-primary btn-sm d-none d-sm-inline-block" role="button" href="#">
                <i className="fas fa-download fa-sm text-white-50"></i>&nbsp;Generate Report
              </a>
            </div>
            
            <DashboardCards />
            
            <div className="row">
              <div className="col-lg-7 col-xl-8">
                <div className="card shadow mb-4">
                  <div className="card-header d-flex justify-content-between align-items-center">
                    <h6 className="text-primary fw-bold m-0">Call Service Overview</h6>
                    <div className="dropdown no-arrow">
                      <button className="btn btn-link btn-sm dropdown-toggle" aria-expanded="false" data-bs-toggle="dropdown" type="button">
                        <i className="fas fa-ellipsis-v text-gray-400"></i>
                      </button>
                      <div className="dropdown-menu shadow dropdown-menu-end animated--fade-in">
                        <p className="text-center dropdown-header">dropdown header:</p>
                        <a className="dropdown-item" href="#"> Action</a>
                        <a className="dropdown-item" href="#"> Another action</a>
                        <div className="dropdown-divider"></div>
                        <a className="dropdown-item" href="#"> Something else here</a>
                      </div>
                    </div>
                  </div>
                  <div className="card-body">
                    <div className="chart-area">
                      <canvas height="320"></canvas>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-lg-5 col-xl-4">
                <div className="card shadow mb-4">
                  <div className="card-header d-flex justify-content-between align-items-center">
                    <h6 className="text-primary fw-bold m-0">CALL SERVICE LEVELS</h6>
                    <div className="dropdown no-arrow">
                      <button className="btn btn-link btn-sm dropdown-toggle" aria-expanded="false" data-bs-toggle="dropdown" type="button">
                        <i className="fas fa-ellipsis-v text-gray-400"></i>
                      </button>
                      <div className="dropdown-menu shadow dropdown-menu-end animated--fade-in">
                        <p className="text-center dropdown-header">dropdown header:</p>
                        <a className="dropdown-item" href="#">&nbsp;Action</a>
                        <a className="dropdown-item" href="#">&nbsp;Another action</a>
                        <div className="dropdown-divider"></div>
                        <a className="dropdown-item" href="#">&nbsp;Something else here</a>
                      </div>
                    </div>
                  </div>
                  <div className="card-body">
                    <div className="chart-area">
                      <Pie data={data} />
                    </div>
                    <div className="text-center small mt-4">
                      <span className="me-2"><i className="fas fa-circle text-primary"></i>&nbsp;WhatsApp Calls</span>
                      <span className="me-2"><i className="fas fa-circle text-success"></i>&nbsp;Normal&nbsp; Calls</span>
                      <span className="me-2"><i className="fas fa-circle text-info"></i>&nbsp;Unanswered Calls</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <footer className="bg-white sticky-footer">
          <div className="container my-auto">
            <div className="text-center my-auto copyright">
              <span>Copyright © WhatsFirst Call Center 2025</span>
            </div>
          </div>
        </footer>
    </div>
    
  );
};

export default Dashboard;